# Call Recorder

Two-way call recorder for Android that works by becoming the device's
**default phone app** (InCallService) and recording each call to `.m4a`.

## Build (no local machine needed)
1. Create a new GitHub repo and push this project.
2. GitHub Actions runs automatically (`.github/workflows/build.yml`).
3. Open the completed run → **Artifacts** → download `call-recorder-debug` → unzip → `app-debug.apk`.
4. Sideload the APK onto your phone (enable "Install unknown apps").

## Use
1. Open the app → **Grant permissions**.
2. Tap **Set as default phone app** and confirm.
3. Make/receive a call. It records automatically. Recordings appear in the list.

## Reality check on Android 10+
Google blocks non-privileged apps from capturing the remote party's audio via
`VOICE_CALL`. The app tries `VOICE_CALL` → `VOICE_COMMUNICATION` → `MIC` and, on
the MIC fallback, forces speakerphone so both sides are captured acoustically.
Results vary by device and OEM ROM. Rooted devices and some brands (older Xiaomi,
some Samsung ROMs) capture both sides cleanly; stock Pixel is the most locked down.

## Files
- `RecordingManager.kt` — MediaRecorder + source fallback + speaker toggle
- `CallRecorderService.kt` — InCallService, starts/stops on call state
- `MainActivity.kt` — role request, permissions, recordings list
- `DialerActivity.kt` — minimal dialer (required for default-phone-app role)

## Legal note
Call-recording consent laws differ by country/state. Some require all parties to
consent. Know the rule where you and the other party are before recording.
