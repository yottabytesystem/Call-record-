package com.yotta.callrecorder

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telecom.TelecomManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var recycler: RecyclerView
    private lateinit var adapter: RecordingsAdapter
    private var player: MediaPlayer? = null

    private val requiredPermissions = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.READ_CALL_LOG)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refreshStatus() }

    private val roleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { refreshStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        recycler = findViewById(R.id.recordingsList)
        adapter = RecordingsAdapter(
            onPlay = { play(it) },
            onDelete = { delete(it) }
        )
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        findViewById<Button>(R.id.grantPermsButton).setOnClickListener {
            permissionLauncher.launch(requiredPermissions)
        }
        findViewById<Button>(R.id.setDefaultButton).setOnClickListener {
            requestDefaultDialer()
        }
        findViewById<Button>(R.id.refreshButton).setOnClickListener {
            loadRecordings()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        loadRecordings()
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }

    private fun refreshStatus() {
        val permsOk = requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
        val defaultOk = isDefaultDialer()
        statusText.text = buildString {
            append("Permissions: ")
            append(if (permsOk) "granted ✓" else "missing ✗")
            append("\nDefault phone app: ")
            append(if (defaultOk) "yes ✓" else "no ✗")
            if (!defaultOk) {
                append("\n\nRecording only runs while this app is the default phone app.")
            }
        }
    }

    private fun isDefaultDialer(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = getSystemService(RoleManager::class.java)
            rm.isRoleHeld(RoleManager.ROLE_DIALER)
        } else {
            val tm = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            packageName == tm.defaultDialerPackage
        }
    }

    private fun requestDefaultDialer() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
            }
        } else {
            @Suppress("DEPRECATION")
            val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
            roleLauncher.launch(intent)
        }
    }

    private fun loadRecordings() {
        val dir = File(getExternalFilesDir(null), "recordings")
        val files = dir.listFiles { f -> f.extension == "m4a" }?.sortedByDescending { it.lastModified() }
            ?: emptyList()
        val items = files.map { f ->
            val parts = f.nameWithoutExtension.split("_")
            val number = parts.getOrNull(2) ?: "unknown"
            Recording(
                file = f,
                displayName = f.name,
                number = number,
                timestampMillis = f.lastModified(),
                sizeBytes = f.length()
            )
        }
        adapter.submit(items)
        if (items.isEmpty()) {
            Toast.makeText(this, "No recordings yet", Toast.LENGTH_SHORT).show()
        }
    }

    private fun play(rec: Recording) {
        player?.release()
        player = MediaPlayer().apply {
            setDataSource(rec.file.absolutePath)
            prepare()
            start()
        }
        val when_ = SimpleDateFormat("MMM d, HH:mm", Locale.US).format(Date(rec.timestampMillis))
        Toast.makeText(this, "Playing ${rec.number} · $when_", Toast.LENGTH_SHORT).show()
    }

    private fun delete(rec: Recording) {
        if (rec.file.delete()) {
            loadRecordings()
            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
        }
    }
}
