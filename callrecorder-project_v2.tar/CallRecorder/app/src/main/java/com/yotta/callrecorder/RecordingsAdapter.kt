package com.yotta.callrecorder

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordingsAdapter(
    private val onPlay: (Recording) -> Unit,
    private val onDelete: (Recording) -> Unit
) : RecyclerView.Adapter<RecordingsAdapter.VH>() {

    private val items = mutableListOf<Recording>()

    fun submit(list: List<Recording>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_recording, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(items[position])
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        private val title: TextView = view.findViewById(R.id.itemNumber)
        private val subtitle: TextView = view.findViewById(R.id.itemMeta)
        private val playBtn: Button = view.findViewById(R.id.itemPlay)
        private val deleteBtn: Button = view.findViewById(R.id.itemDelete)

        fun bind(rec: Recording) {
            title.text = rec.number.ifBlank { "Unknown" }
            val date = SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.US)
                .format(Date(rec.timestampMillis))
            val kb = rec.sizeBytes / 1024
            subtitle.text = "$date · ${kb} KB"
            playBtn.setOnClickListener { onPlay(rec) }
            deleteBtn.setOnClickListener { onDelete(rec) }
        }
    }
}
