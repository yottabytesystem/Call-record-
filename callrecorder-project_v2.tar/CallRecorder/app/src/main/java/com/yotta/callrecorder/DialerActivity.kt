package com.yotta.callrecorder

import android.net.Uri
import android.os.Bundle
import android.telecom.TelecomManager
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

/**
 * A bare-bones dialer. Android requires the default phone app to be able to
 * place calls, so this exists to satisfy that contract and to let you test
 * outgoing-call recording. It is intentionally minimal.
 */
class DialerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dialer)

        val input = findViewById<EditText>(R.id.numberInput)

        // Prefill if launched from a tel: intent.
        intent?.data?.let { uri ->
            if (uri.scheme == "tel") input.setText(uri.schemeSpecificPart)
        }

        findViewById<Button>(R.id.callButton).setOnClickListener {
            val number = input.text.toString().trim()
            if (number.isNotEmpty()) placeCall(number)
        }
    }

    private fun placeCall(number: String) {
        val telecom = getSystemService(TELECOM_SERVICE) as TelecomManager
        val uri = Uri.fromParts("tel", number, null)
        try {
            telecom.placeCall(uri, Bundle())
        } catch (_: SecurityException) {
            // Not the default dialer yet; MainActivity handles requesting that.
        }
        finish()
    }
}
