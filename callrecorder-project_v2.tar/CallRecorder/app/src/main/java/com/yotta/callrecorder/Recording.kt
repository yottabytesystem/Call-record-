package com.yotta.callrecorder

import java.io.File

data class Recording(
    val file: File,
    val displayName: String,
    val number: String,
    val timestampMillis: Long,
    val sizeBytes: Long
)
