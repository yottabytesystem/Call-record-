package com.yotta.callrecorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.telecom.Call
import android.telecom.InCallService
import android.util.Log

/**
 * Registered as the device's InCallService. Once this app is the default
 * phone app, Android delivers every call here. We watch each call's state and
 * start recording when it goes ACTIVE, stop when it disconnects.
 */
class CallRecorderService : InCallService() {

    companion object {
        private const val TAG = "CallRecorderService"
        private const val CHANNEL_ID = "call_recording"
        private const val NOTIF_ID = 42
    }

    private lateinit var recordingManager: RecordingManager
    private val callbacks = HashMap<Call, Call.Callback>()

    override fun onCreate() {
        super.onCreate()
        recordingManager = RecordingManager(applicationContext)
        createChannel()
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        val cb = object : Call.Callback() {
            override fun onStateChanged(c: Call, state: Int) {
                handleState(c, state)
            }
        }
        callbacks[call] = cb
        call.registerCallback(cb)
        // A call can already be ACTIVE by the time we're added.
        handleState(call, call.state)
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        callbacks.remove(call)?.let { call.unregisterCallback(it) }
        if (callbacks.isEmpty()) {
            stopRecording()
        }
    }

    private fun handleState(call: Call, state: Int) {
        when (state) {
            Call.STATE_ACTIVE -> startRecording(call)
            Call.STATE_DISCONNECTED -> {
                if (callbacks.isEmpty()) stopRecording()
            }
        }
    }

    private fun startRecording(call: Call) {
        if (recordingManager.isRecording) return
        val number = extractNumber(call)
        startForegroundNotification()
        val file = recordingManager.start(number)
        if (file == null) {
            Log.e(TAG, "Failed to start recording for $number")
            stopForeground(STOP_FOREGROUND_REMOVE)
        }
    }

    private fun stopRecording() {
        if (recordingManager.isRecording) {
            recordingManager.stop()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun extractNumber(call: Call): String {
        val handle = call.details?.handle
        return handle?.schemeSpecificPart ?: ""
    }

    private fun startForegroundNotification() {
        val notif: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Recording call")
            .setContentText("Tap to open Call Recorder")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Call recording",
            NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(channel)
    }
}
