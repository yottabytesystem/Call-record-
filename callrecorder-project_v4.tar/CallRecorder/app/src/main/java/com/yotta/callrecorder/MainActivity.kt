package com.yotta.callrecorder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var adapter: RecordingsAdapter
    private var player: MediaPlayer? = null

    private val requiredPermissions = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.READ_CALL_LOG)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refreshStatus() }

    private val overlayLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { refreshStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        val recycler = findViewById<RecyclerView>(R.id.recordingsList)
        adapter = RecordingsAdapter(onPlay = { play(it) }, onDelete = { delete(it) })
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        findViewById<Button>(R.id.grantPermsButton).setOnClickListener {
            permissionLauncher.launch(requiredPermissions)
        }
        findViewById<Button>(R.id.overlayButton).setOnClickListener {
            requestOverlay()
        }
        findViewById<Button>(R.id.startButton).setOnClickListener {
            startMonitoring()
        }
        findViewById<Button>(R.id.stopButton).setOnClickListener {
            stopMonitoring()
        }
        findViewById<Button>(R.id.refreshButton).setOnClickListener {
            loadRecordings()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        loadRecordings()
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }

    private fun permsGranted() = requiredPermissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun overlayGranted() = Settings.canDrawOverlays(this)

    private fun refreshStatus() {
        statusText.text = buildString {
            append("Permissions: ")
            append(if (permsGranted()) "granted \u2713" else "missing \u2717")
            append("\nOverlay (draw over apps): ")
            append(if (overlayGranted()) "granted \u2713" else "missing \u2717")
            append("\n\nGrant both, then tap Start monitoring. A draggable bubble appears during calls and records automatically.")
        }
    }

    private fun requestOverlay() {
        if (!overlayGranted()) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayLauncher.launch(intent)
        } else {
            Toast.makeText(this, "Overlay already granted", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startMonitoring() {
        if (!permsGranted()) {
            Toast.makeText(this, "Grant permissions first", Toast.LENGTH_SHORT).show()
            return
        }
        if (!overlayGranted()) {
            Toast.makeText(this, "Grant overlay first", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, CallMonitorService::class.java)
        ContextCompat.startForegroundService(this, intent)
        Toast.makeText(this, "Monitoring started", Toast.LENGTH_SHORT).show()
    }

    private fun stopMonitoring() {
        stopService(Intent(this, CallMonitorService::class.java))
        Toast.makeText(this, "Monitoring stopped", Toast.LENGTH_SHORT).show()
    }

    private fun loadRecordings() {
        val dir = File(getExternalFilesDir(null), "recordings")
        val files = dir.listFiles { f -> f.extension == "m4a" }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
        val items = files.map { f ->
            val parts = f.nameWithoutExtension.split("_")
            Recording(
                file = f,
                displayName = f.name,
                number = parts.getOrNull(2) ?: "unknown",
                timestampMillis = f.lastModified(),
                sizeBytes = f.length()
            )
        }
        adapter.submit(items)
    }

    private fun play(rec: Recording) {
        player?.release()
        player = MediaPlayer().apply {
            setDataSource(rec.file.absolutePath)
            prepare()
            start()
        }
        Toast.makeText(this, "Playing ${rec.number}", Toast.LENGTH_SHORT).show()
    }

    private fun delete(rec: Recording) {
        if (rec.file.delete()) {
            loadRecordings()
            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
        }
    }
}
