package com.yotta.callrecorder

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs

/**
 * A small draggable overlay ("chat head" style). Sits in a corner, can be
 * dragged anywhere, snaps to the nearest side edge when released, and shows a
 * live recording timer. Tapping it (without dragging) toggles recording.
 */
class FloatingBubble(
    private val context: Context,
    private val onToggle: () -> Unit
) {
    private val windowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: View? = null
    private lateinit var params: WindowManager.LayoutParams

    private val handler = Handler(Looper.getMainLooper())
    private var seconds = 0
    private var recording = false

    private val ticker = object : Runnable {
        override fun run() {
            seconds++
            updateLabel()
            handler.postDelayed(this, 1000)
        }
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    fun show() {
        if (view != null) return

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 240
        }

        val v = LayoutInflater.from(context).inflate(R.layout.bubble, null)
        v.setOnTouchListener(DragListener())
        view = v
        windowManager.addView(v, params)
        updateLabel()
    }

    fun setRecording(isRecording: Boolean) {
        recording = isRecording
        seconds = 0
        handler.removeCallbacks(ticker)
        if (isRecording) handler.post(ticker)
        updateLabel()
    }

    fun hide() {
        handler.removeCallbacks(ticker)
        view?.let { runCatching { windowManager.removeView(it) } }
        view = null
    }

    private fun updateLabel() {
        val label = view?.findViewById<TextView>(R.id.bubbleLabel) ?: return
        val dot = if (recording) "●" else "○"
        val mm = seconds / 60
        val ss = seconds % 60
        label.text = if (recording) {
            String.format("%s REC\n%02d:%02d", dot, mm, ss)
        } else {
            "$dot IDLE"
        }
    }

    private inner class DragListener : View.OnTouchListener {
        private var initialX = 0
        private var initialY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    runCatching { windowManager.updateViewLayout(v, params) }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        onToggle()
                    } else {
                        snapToEdge(v)
                    }
                    return true
                }
            }
            return false
        }

        private fun snapToEdge(v: View) {
            val screenWidth = context.resources.displayMetrics.widthPixels
            val centerX = params.x + v.width / 2
            params.x = if (centerX < screenWidth / 2) 24 else screenWidth - v.width - 24
            runCatching { windowManager.updateViewLayout(v, params) }
        }
    }
}
