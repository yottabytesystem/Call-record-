package com.yotta.callrecorder

import android.content.Context
import android.media.AudioManager
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Owns a single MediaRecorder instance for the lifetime of one call.
 *
 * Android 10+ blocks VOICE_CALL / VOICE_DOWNLINK capture for non-privileged
 * apps, so we try the most-capable source first and fall back until one
 * actually starts. As a last resort we force speakerphone on and record from
 * the MIC, which picks up both sides acoustically.
 */
class RecordingManager(private val context: Context) {

    companion object {
        private const val TAG = "RecordingManager"

        // Tailored for locked-down OEM ROMs (MagicOS 10 / Android 16), where
        // VOICE_CALL "starts" but records silence. We go MIC-first with the
        // speaker forced on, which captures both sides acoustically and is the
        // most likely to contain audible audio on these devices.
        private val SOURCE_CHAIN = listOf(
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.VOICE_CALL
        )
    }

    private var recorder: MediaRecorder? = null
    private var currentFile: File? = null
    private var usedSpeakerHack = false
    private var speakerWasOn = false

    val isRecording: Boolean
        get() = recorder != null

    /**
     * @param number the remote party's number (may be empty for private/unknown)
     * @return the File being written to, or null if every source failed.
     */
    fun start(number: String): File? {
        if (recorder != null) {
            Log.w(TAG, "start() called while already recording")
            return currentFile
        }

        val dir = File(context.getExternalFilesDir(null), "recordings").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safeNumber = number.ifBlank { "unknown" }.replace(Regex("[^0-9+]"), "")
        val outFile = File(dir, "${stamp}_${safeNumber.ifBlank { "unknown" }}.m4a")

        for (source in SOURCE_CHAIN) {
            if (tryStart(source, outFile)) {
                currentFile = outFile
                Log.i(TAG, "Recording started with source=$source -> ${outFile.name}")
                return outFile
            }
        }

        Log.e(TAG, "All audio sources failed")
        return null
    }

    private fun tryStart(source: Int, outFile: File): Boolean {
        // For MIC we need both sides audible, so drive audio to the speaker.
        if (source == MediaRecorder.AudioSource.MIC) {
            enableSpeakerphone()
            usedSpeakerHack = true
        }

        val r = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }

        return try {
            r.setAudioSource(source)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(outFile.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            true
        } catch (e: Exception) {
            Log.w(TAG, "source=$source failed: ${e.message}")
            runCatching { r.reset() }
            runCatching { r.release() }
            if (usedSpeakerHack) restoreSpeakerphone()
            usedSpeakerHack = false
            outFile.delete()
            false
        }
    }

    /** @return the finished File, or null if nothing was recorded. */
    fun stop(): File? {
        val r = recorder ?: return null
        val file = currentFile
        try {
            r.stop()
        } catch (e: RuntimeException) {
            // stop() throws if it started but captured no valid frames.
            Log.w(TAG, "stop() failed, discarding: ${e.message}")
            runCatching { r.release() }
            recorder = null
            currentFile = null
            file?.delete()
            if (usedSpeakerHack) restoreSpeakerphone()
            usedSpeakerHack = false
            return null
        }
        runCatching { r.release() }
        recorder = null
        currentFile = null
        if (usedSpeakerHack) restoreSpeakerphone()
        usedSpeakerHack = false
        Log.i(TAG, "Recording stopped -> ${file?.name}")
        return file
    }

    private fun enableSpeakerphone() {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        speakerWasOn = am.isSpeakerphoneOn
        @Suppress("DEPRECATION")
        am.isSpeakerphoneOn = true
    }

    private fun restoreSpeakerphone() {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        @Suppress("DEPRECATION")
        am.isSpeakerphoneOn = speakerWasOn
    }
}
