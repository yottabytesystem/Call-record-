package com.yotta.callrecorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.app.ServiceCompat

/**
 * Runs in the foreground and watches the call state. When a call becomes
 * active (off-hook), it shows the floating bubble and starts recording; when
 * the call ends (idle), it stops recording and hides the bubble.
 *
 * This path does NOT require being the default phone app, so Play Protect's
 * default-dialer block does not apply.
 */
class CallMonitorService : android.app.Service() {

    companion object {
        private const val TAG = "CallMonitorService"
        private const val CHANNEL_ID = "call_monitor"
        private const val NOTIF_ID = 7
    }

    private lateinit var recordingManager: RecordingManager
    private var bubble: FloatingBubble? = null
    private val main = Handler(Looper.getMainLooper())

    private var telephonyManager: TelephonyManager? = null
    private var legacyListener: PhoneStateListener? = null
    private var modernCallback: TelephonyCallback? = null

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        recordingManager = RecordingManager(applicationContext)
        createChannel()
        startForegroundNotification()
        registerCallListener()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun registerCallListener() {
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        telephonyManager = tm

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) {
                    handleState(state)
                }
            }
            modernCallback = cb
            tm.registerTelephonyCallback(mainExecutor, cb)
        } else {
            val listener = object : PhoneStateListener() {
                @Deprecated("Deprecated in Java")
                override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                    handleState(state)
                }
            }
            legacyListener = listener
            @Suppress("DEPRECATION")
            tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
        }
    }

    private fun handleState(state: Int) {
        when (state) {
            TelephonyManager.CALL_STATE_OFFHOOK -> onCallActive()
            TelephonyManager.CALL_STATE_IDLE -> onCallEnded()
            TelephonyManager.CALL_STATE_RINGING -> { /* wait for off-hook */ }
        }
    }

    private fun onCallActive() {
        main.post {
            if (bubble == null) {
                bubble = FloatingBubble(this) { toggleRecording() }
            }
            bubble?.show()
            startRecording()
        }
    }

    private fun onCallEnded() {
        main.post {
            stopRecording()
            bubble?.hide()
        }
    }

    private fun toggleRecording() {
        if (recordingManager.isRecording) stopRecording() else startRecording()
    }

    private fun startRecording() {
        if (recordingManager.isRecording) return
        val number = lastCallNumber()
        val file = recordingManager.start(number)
        if (file != null) {
            bubble?.setRecording(true)
        } else {
            Log.e(TAG, "Recording failed to start")
            bubble?.setRecording(false)
        }
    }

    private fun stopRecording() {
        if (recordingManager.isRecording) {
            recordingManager.stop()
        }
        bubble?.setRecording(false)
    }

    /** Best-effort: read the most recent call-log number to label the file. */
    private fun lastCallNumber(): String {
        return try {
            contentResolver.query(
                android.provider.CallLog.Calls.CONTENT_URI,
                arrayOf(android.provider.CallLog.Calls.NUMBER),
                null, null,
                "${android.provider.CallLog.Calls.DATE} DESC"
            )?.use { c ->
                if (c.moveToFirst()) c.getString(0) ?: "" else ""
            } ?: ""
        } catch (_: SecurityException) {
            ""
        }
    }

    private fun startForegroundNotification() {
        val notif: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Call Recorder active")
            .setContentText("Watching for calls")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, NOTIF_ID, notif,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        )
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID, "Call monitor",
                NotificationManager.IMPORTANCE_LOW
            )
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        stopRecording()
        bubble?.hide()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            modernCallback?.let { telephonyManager?.unregisterTelephonyCallback(it) }
        } else {
            @Suppress("DEPRECATION")
            legacyListener?.let { telephonyManager?.listen(it, PhoneStateListener.LISTEN_NONE) }
        }
    }
}
