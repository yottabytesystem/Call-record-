# Call Recorder (floating bubble)

Records calls using a draggable floating bubble overlay. Does NOT need to be
the default phone app, so Play Protect's default-dialer block does not apply.

## How it works
1. Grant permissions + overlay ("draw over other apps").
2. Tap "Start monitoring" — a foreground service watches the call state.
3. On any call (in or out), a draggable bubble appears and recording starts.
4. Drag the bubble anywhere; it snaps to the nearest edge. Tap it to stop/start.
5. Call ends -> recording saved, bubble hides. Files listed in the app.

## Build via GitHub Actions
Upload the tar + paste .github/workflows/build.yml, push, download the
`call-recorder-debug` artifact -> app-debug.apk -> sideload.

## Two-way audio reality (unchanged)
Android 10+ blocks remote-party capture for non-privileged apps. The recorder
tries VOICE_CALL -> VOICE_COMMUNICATION -> MIC (with speakerphone forced on the
MIC fallback). Clean two-way needs root or a supporting OEM ROM.
